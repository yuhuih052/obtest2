layui.define(function(exports){
	alert('我来自自定义组件模块');
	exports('custom',{});
});